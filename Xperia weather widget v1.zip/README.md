# **Xperia Weather Widget**
This Magic module Installs Xperia Weather Widget App On Your Awesome Phone.|Tested on Redmi Y2/S2 thanks to Chetan L|. |Tested on Note 5 Pro thanks to Akshay|
Should work on all other phone running android lollipop and above. For suggestions /report join https://t.me/magicmods (telegram)

